import 'package:flutter/material.dart';
import 'package:hedieaty/controllers/home_controller.dart';
import 'package:hedieaty/controllers/event_controller.dart';
import 'package:hedieaty/controllers/auth_controller.dart';
import 'package:hedieaty/views/MyPledgedGiftsPage.dart';
import 'package:hedieaty/views/EventListPage.dart';
import 'package:hedieaty/views/ProfilePage.dart';
import 'package:hedieaty/views/SignInPage.dart';

class HomeFriendsListScreen extends StatefulWidget {
  const HomeFriendsListScreen({super.key});

  @override
  _HomeFriendsListScreenState createState() => _HomeFriendsListScreenState();
}

class _HomeFriendsListScreenState extends State<HomeFriendsListScreen> {
  final HomeController _homeController = HomeController();
  final EventController _eventController = EventController();
  final AuthController _authController = AuthController();

  late Future<List<Map<String, dynamic>>> _friendsFuture;
  String searchQuery = '';
  int _selectedIndex = 0;
  Map<String, String> userData = {};
  List<Map<String, dynamic>> filteredFriends = [];

  @override
  void initState() {
    super.initState();
    _fetchFriends();
    _fetchUserData();
  }

  void _fetchFriends() async {
    String? userId = await _authController.getCurrentUserId();

    if (userId != null) {
      setState(() {
        _friendsFuture = _homeController.getFriendsForView(userId);
      });
      _friendsFuture.then((friends) {
        setState(() {
          filteredFriends = friends;
        });
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error: No user is signed in.")),
      );
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => SignInPage()),
      );
    }
  }

  void _fetchUserData() async {
    final user = await _authController.getUserProfile();
    if (user != null) setState(() => userData = user);
  }

  void _filterFriends(String query) {
    setState(() {
      searchQuery = query;
      filteredFriends = filteredFriends
          .where((friend) =>
          friend['name']!.toLowerCase().contains(searchQuery.toLowerCase()))
          .toList();
    });
  }

  void _signOut() async {
    await _authController.signOut();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => SignInPage()));
  }

  Future<void> _onItemTapped(int index) async {
    setState(() => _selectedIndex = index);

    switch (index) {
      case 0:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const HomeFriendsListScreen()),
        );
        break;

      case 1: // Navigate to My Events
        String? userId = await _authController.getCurrentUserId();
        if (userId != null) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => EventListPage(friendName: 'My Events', userId: userId),
            ),
          );
        }
        break;

      case 2: // Navigate to Pledged Gifts
        String? userId = await _authController.getCurrentUserId();
        if (userId != null) {
          try {
            // Fetch events as a list of maps for UI
            List<Map<String, dynamic>> events = await _eventController.fetchEventsForView(userId);

            if (events.isNotEmpty) {
              String eventId = events.first['id']; // Get the first event's ID
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => MyPledgedGiftsPage(
                    userId: userId,
                    eventId: eventId,
                  ),
                ),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("No events found for this user.")),
              );
            }
          } catch (e) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Error fetching events: $e")),
            );
          }
        }
        break;

      case 3: // Navigate to Profile
        String? userId = await _authController.getCurrentUserId();
        if (userId != null) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => ProfilePage()),
          );
        }
        break;

      default:
        break;
    }
  }


  void _deleteFriend(String friendId) async {
    String? userId = await _authController.getCurrentUserId();
    if (userId != null) {
      await _homeController.deleteFriend(userId, friendId);
      _fetchFriends(); // Refresh friend list after deletion
    }
  }

  Widget _buildFriendTile(Map<String, dynamic> friend) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: friend['profilePicture'] != null
            ? AssetImage(friend['profilePicture']!)
            : const AssetImage('assets/images/profile1.png'),
      ),
      title: Text(friend['name']!, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('View Events for ${friend['name']}'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.event, color: Colors.blue),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      EventListPage(friendName: friend['name']!, userId: friend['friendId']),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () => _deleteFriend(friend['friendId']),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Friends List', style: TextStyle(color: Colors.black)),
        backgroundColor: const Color(0xffba8fe3),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add),
            onPressed: () async {
              String? userId = await _authController.getCurrentUserId();
              if (userId != null) {
                _homeController.addFriendManually(context, userId, _fetchFriends);
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _signOut,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search friends...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(50)),
                prefixIcon: const Icon(Icons.search),
              ),
              onChanged: _filterFriends,
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _friendsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('No friends found.'));
                }
                return ListView(
                  children: filteredFriends
                      .map((friend) => _buildFriendTile(friend))
                      .toList(),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.black54,
        backgroundColor: const Color(0xffba8fe3),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.event),
            label: 'My Events',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: 'Pledged Gifts',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}