import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PledgedController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Fetch pledged gifts as a stream of formatted maps
  Future<List<Map<String, dynamic>>> fetchPledgedGifts(String userId) async {
    try {
      final querySnapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('pledgedGifts')
          .get();

      return querySnapshot.docs.map((doc) {
        return {
          ...doc.data(),
          'id': doc.id,
        };
      }).toList();
    } catch (e) {
      print('Error fetching pledged gifts: $e');
      return [];
    }
  }

  /// Toggle the pledge status of a gift
  Future<void> togglePledgeStatus({
    required String friendId,
    required String eventId,
    required String giftId,
    required bool isPledged,
  }) async {
    if (isPledged) {
      await unpledgeGift(friendId: friendId, eventId: eventId, giftId: giftId);
    } else {
      await pledgeGift(friendId: friendId, eventId: eventId, giftId: giftId);
    }
  }

  Future<void> pledgeGift({
    required String friendId,
    required String eventId,
    required String giftId,
  }) async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) throw Exception('User not logged in!');

    final giftSnapshot = await _firestore
        .collection('users')
        .doc(friendId)
        .collection('events')
        .doc(eventId)
        .collection('gifts')
        .doc(giftId)
        .get();

    if (!giftSnapshot.exists) throw Exception('Gift not found!');

    final giftData = giftSnapshot.data();

    await _firestore
        .collection('users')
        .doc(userId)
        .collection('pledgedGifts')
        .doc(giftId)
        .set({
      ...giftData!,
      'pledgedFrom': friendId,
      'status': 'pledged',
    });

    await _firestore
        .collection('users')
        .doc(friendId)
        .collection('events')
        .doc(eventId)
        .collection('gifts')
        .doc(giftId)
        .update({'status': 'pledged'});
  }

  Future<void> unpledgeGift({
    required String friendId,
    required String eventId,
    required String giftId,
  }) async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) throw Exception('User not logged in!');

    await _firestore
        .collection('users')
        .doc(userId)
        .collection('pledgedGifts')
        .doc(giftId)
        .delete();

    await _firestore
        .collection('users')
        .doc(friendId)
        .collection('events')
        .doc(eventId)
        .collection('gifts')
        .doc(giftId)
        .update({'status': 'available'});
  }
}
